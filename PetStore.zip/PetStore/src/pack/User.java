package pack;
import java.util.*;
class User {
	String firstName;
	String lastName;
	String email;
	double budget;
	public User(String firstName, String lastName, String email, double budget) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.budget = budget;
	}
	public void listUsers()
	{
		System.out.println("First Name: "+firstName+"\t"+"Last Name: "+lastName+"\t"+"Email: "+email+"\t"+"Budget: "+budget);
	}
}
