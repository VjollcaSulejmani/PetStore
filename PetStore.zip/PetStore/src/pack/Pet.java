package pack;
import java.text.*;
import java.util.*;
import java.time.*;

enum Type{
	dog,cat
}
class Pet {
	User owner;
	String name;
	String description;
	Type type;
	double price;
	String birthDate;
	int rating;
	public Pet(User owner, String name, String description, Type type,String birthDate,int rating)  {
		super();
		this.owner = owner;
		this.name = name;
		this.description = description;
		this.type = type; 
		this.birthDate = birthDate;
		this.rating=rating;
		this.price = setPrice();
	}
	
	public double setPrice()
	{
		LocalDate now = LocalDate.now();
		String str[]=birthDate.split("/"); 
		LocalDate date = LocalDate.of(Integer.parseInt(str[2]),Integer.parseInt(str[1]),Integer.parseInt(str[0]));
		int years = Period.between(date,now).getYears();
		if(type.equals(Type.dog))
		{
			this.price = years+rating;
		}
		else if(type.equals(Type.cat))
		{
			this.price = years;
		}
		return this.price;
	}
	public void listPets()
	{
		System.out.println("Owner: "+owner+"\t"+"Type: "+type+"\t"+"Name: "+name+"\t"+"Birthdate: "+birthDate+"\t"+"Price: "+price+"\t"+"Description: "+description);	
	}
}
