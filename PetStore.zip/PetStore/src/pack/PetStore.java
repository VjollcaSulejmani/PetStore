package pack;
import java.util.*;
import java.text.*;
import java.time.*;
import java.io.BufferedReader;
public class PetStore {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		
		ArrayList<Pet> pet = new ArrayList<Pet>(); 
		ArrayList<User> user = new ArrayList<User>(); 
		user.add(new User("Miranda","Swift","mswift@gmail.com",13.5));
		user.add(new User("George","Smith","gsmith@gmail.com",7.5));
		user.add(new User("Mila","Cowell","mcowell@gmail.com",15.2));
		
		pet.add(new Pet(null,"Tom","Tom loves playing outside",Type.dog,"10/02/2015",6));
		pet.add(new Pet(null,"Coco","Coco likes to cuddle",Type.cat,"11/03/2017",0));
		pet.add(new Pet(null,"Miki","Miki is very friendly",Type.cat,"12/07/2019",0));
		pet.add(new Pet(null,"Loco","Loco likes running",Type.dog,"22/05/2010",7));
		pet.add(new Pet(null,"Rico","Rico is very sleepy",Type.cat,"17/09/2018",0));

		System.out.println("Please enter 1 if you want to list users");
		System.out.println("Please enter 2 if you want to list pets");
		System.out.println("Please enter 3 if you want to create user");
		System.out.println("Please enter 4 if you want to create pet");
		System.out.println("Please enter 5 if you want to buy a pet for each user");
		
		System.out.println("Please enter 'exit' if you want to terminate program");
		
		String choice = " ";
		while(!choice.equals("exit")){
			choice = input.nextLine();
		switch (choice) {
		case "1":
			int i = 0;
			for(User a : user)
			{
				System.out.print("ID: "+i+"\t");
				a.listUsers();
				i++;
				
			}
			break;
		
		case "2":
			int j = 0;
			for(Pet a : pet)
			{
				System.out.print("ID: "+j+"\t");
				a.listPets();
				j++;
			}
			break;
		case "3":
			if(user.size()==10)
				System.out.println("You cannot add new user since full");
			else
				{
				System.out.println("Enter First Name: ");
				String firstName = input.nextLine();
				System.out.println("Enter Last Name: ");
				String lastName = input.nextLine();
				System.out.println("Enter email: ");
				String email = input.nextLine();
				System.out.println("Enter budget: ");
				double budget = Double.parseDouble(input.nextLine());

				User obj = new User(firstName,lastName,email,budget);
				user.add(obj);
				System.out.println("User added successfully ");
				}
			break;
		case "4":
			if(pet.size()==20)
				System.out.println("You cannot add new pet since full");
			else
				{
				System.out.println("Enter pet type(cat,dog): ");
				Type type = null;
				{
					String str = input.nextLine();
					if(str.equals("dog"))
						type = Type.dog;
					else if(str.equals("cat"))
						type = Type.cat;
					else
						System.out.println("Invalid input");
						
				}
				System.out.println("Enter name: ");
				String name = input.nextLine();
				System.out.println("Enter birthDate: ");
				String birthDate = input.nextLine();
				System.out.println("Enter description: ");
				String description = input.nextLine();
				int rating=0;
				if(type.equals(Type.dog))	
				{
					System.out.println("Enter dog rating: ");
					rating = Integer.parseInt(input.nextLine());
				}
				Pet obj = new Pet(null, name, description, type, birthDate, rating);
				pet.add(obj);
				System.out.println("Pet added successfully ");
				
				}
			break;
		case "5":
			System.out.println("Type user ID that wants to buy a pet");
			int userId = input.nextInt();
			System.out.println("Type pet ID that you want to buy");
			int petId = input.nextInt();
			if(user.get(userId).budget>=pet.get(petId).price && pet.get(petId).owner==null)
			{
				pet.get(petId).owner = user.get(userId);
				if(pet.get(petId).type.equals(Type.cat))
					System.out.println("Meow,cat "+pet.get(petId).name+" has owner "+pet.get(petId).owner.firstName);
				else
					System.out.println("Woof,dog "+pet.get(petId).name+" has owner "+pet.get(petId).owner.firstName);
			}
			else
			{
				System.out.println("You cannot buy this pet");
			}
			
			break;
		}
	
	}	
	}
		
}
