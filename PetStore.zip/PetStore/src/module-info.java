/**
 * 
 */
/**
 * @author Vjollcaa
 *
 */
module PetStore {
}